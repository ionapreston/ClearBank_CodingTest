﻿using ClearBank.DeveloperTest.Data;
using System.Reflection.Metadata.Ecma335;

namespace ClearBank.DeveloperTest.Factories
{
    public class AccountDataStoryFactory : IAccountDataStoreFactory
    {
        private readonly string _dataStoreType;
        private readonly string BACKUPTYPE = "Backup";

        public AccountDataStoryFactory(string dataStoreType) 
        { 
            _dataStoreType = dataStoreType;
        }

        public IAccountDataStore Create()
        {
            return _dataStoreType == BACKUPTYPE ? new BackupAccountDataStore() : new CurrentAccountDataStore();
        }
    }
}
