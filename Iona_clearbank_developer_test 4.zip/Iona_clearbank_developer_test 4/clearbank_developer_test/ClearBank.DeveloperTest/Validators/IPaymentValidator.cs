﻿using ClearBank.DeveloperTest.Types;

namespace ClearBank.DeveloperTest.Validators
{
    public interface IPaymentValidator
    {
        bool IsPaymentValid(Account account, decimal paymentAmount);
    }
}
