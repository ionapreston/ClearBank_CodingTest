﻿using ClearBank.DeveloperTest.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ClearBank.DeveloperTest.Validators
{
    public class FasterPaymentValidator : IPaymentValidator
    {
        public bool IsPaymentValid(Account account, decimal paymentAmount)
        {
            return account != null && account.AllowedPaymentSchemes.HasFlag(AllowedPaymentSchemes.FasterPayments) && account.Balance > paymentAmount;
        }
    }
}