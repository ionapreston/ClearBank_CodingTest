﻿using ClearBank.DeveloperTest.Types;
using ClearBank.DeveloperTest.Validators;

namespace ClearBank.DeveloperTest.Selectors
{
    public class PaymentRuleSelector
    {
        public PaymentRuleSelector() { }

        public IPaymentValidator GetPaymentRule(PaymentScheme paymentScheme)
        {
            return paymentScheme switch
            {
                PaymentScheme.FasterPayments => new FasterPaymentValidator(),
                PaymentScheme.Chaps => new ChapsValidator(),
                PaymentScheme.Bacs => new BacsValidator(),
                _ => throw new System.ArgumentOutOfRangeException()
            };

        }
    }
}
