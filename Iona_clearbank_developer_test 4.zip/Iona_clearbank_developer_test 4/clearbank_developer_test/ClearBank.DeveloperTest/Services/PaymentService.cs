﻿using ClearBank.DeveloperTest.Factories;
using ClearBank.DeveloperTest.Selectors;
using ClearBank.DeveloperTest.Types;

namespace ClearBank.DeveloperTest.Services
{
    public class PaymentService(IAccountDataStoreFactory accountDataStoreFactory, PaymentRuleSelector paymentRuleSelector) : IPaymentService
    {
        private readonly IAccountDataStoreFactory _accountDataStoreFactory = accountDataStoreFactory;
        private readonly PaymentRuleSelector _paymentRuleSelector = paymentRuleSelector;
        public MakePaymentResult MakePayment(MakePaymentRequest request)
        {
            //Retrieve the type of data store from the dataStore Factory and get the account
            var accountDataStore = _accountDataStoreFactory.Create();
            var account = accountDataStore.GetAccount(request.DebtorAccountNumber);

            //Get the payment rule type based on the request and validate request
            var paymentRule = _paymentRuleSelector.GetPaymentRule(request.PaymentScheme);
            var isPaymentValid = paymentRule.IsPaymentValid(account, request.Amount);

            //If valid make payment and update account
            if (isPaymentValid)
            {
                account.Balance -= request.Amount;
                accountDataStore.UpdateAccount(account);
            }

            return new MakePaymentResult { Success = isPaymentValid };
        }
    }
}
