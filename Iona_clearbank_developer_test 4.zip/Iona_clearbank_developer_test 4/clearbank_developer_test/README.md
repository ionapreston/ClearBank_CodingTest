### README - Iona Clear Bank Developer Task



Areas of code that need refactored or changed that I managed in the time constraints



* Tests need to be added. Follow a TDD approach, add xUnit and Moq to project for tests
* Refactor the approach to getting the data store - looking at the code the most suitable way to do this would be to use the factory pattern here to retrieve the data store type. This will remove duplicate logic
* The data store types can have a shared interface for the two methods GetAccount + UpdateAccount
* Move out the validation on the type of payment scheme to a Strategy Pattern. Can add a selector here to determine which validator the logic should be checking. Validators can have a shared interface. This will remove duplicate logic
* Refactor result to be a makePaymentResult object
* Add in dependency injection.



Further improvements if I had more time:

* Add a startup for the application - with clear dependency injection. The \_accountDataStoreFactory would be set up here properly and the DataStoreType would be passed in here.
* Add a small console app so you can see visually it working 
* Add in relevant logging
* Could have added some comments to the code however, as it is such a small project I have only left a few in this code. For larger more complex projects I would recommend this for readability.
