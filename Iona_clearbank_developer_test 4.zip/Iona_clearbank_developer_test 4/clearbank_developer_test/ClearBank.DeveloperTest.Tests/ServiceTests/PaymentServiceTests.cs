﻿using ClearBank.DeveloperTest.Data;
using ClearBank.DeveloperTest.Factories;
using ClearBank.DeveloperTest.Selectors;
using ClearBank.DeveloperTest.Services;
using ClearBank.DeveloperTest.Tests.Builders;
using ClearBank.DeveloperTest.Types;
using ClearBank.DeveloperTest.Validators;
using Moq;
using Xunit;

namespace ClearBank.DeveloperTest.Tests.ServiceTests
{
    public class PaymentServiceTests
    {
        private readonly AccountBuilder accountBuilder = new AccountBuilder();

        [Fact]
        public void MakePayment_ShouldReturnSuccessfulPaymentResponse_BasedOnRequest()
        {
            //Arrange
            var request = new MakePaymentRequest
            {
                Amount = 55m,
                PaymentScheme = PaymentScheme.Bacs
            };

            var account = accountBuilder.GetAccount("TEST", 155m, AccountStatus.Live, AllowedPaymentSchemes.Bacs);

            var accountDataStoreMock = new Mock<IAccountDataStore>();
            accountDataStoreMock.Setup(x => x.GetAccount(It.IsAny<string>())).Returns(account);
            accountDataStoreMock.Setup(x => x.UpdateAccount(It.IsAny<Account>()));

            var accountDataStoreFactoryMock = new Mock<IAccountDataStoreFactory>();
            accountDataStoreFactoryMock.Setup(x => x.Create()).Returns(accountDataStoreMock.Object);

            var paymentValidatorMock = new Mock<IPaymentValidator>();
            paymentValidatorMock.Setup(x => x.IsPaymentValid(It.IsAny<Account>(), It.IsAny<decimal>())).Returns(true);

            var service = new PaymentService(accountDataStoreFactoryMock.Object, new PaymentRuleSelector());

            // Act
            var result = service.MakePayment(request);

            //Assert
            Assert.True(result.Success);
            Assert.Equal(100, account.Balance);
            accountDataStoreMock.Verify(x => x.UpdateAccount(It.IsAny<Account>()), Times.Once);

        }

        [Fact]
        public void MakePayment_ShouldReturnFailedPaymentResponse_BasedOnRequest()
        {
            //Arrange
            var request = new MakePaymentRequest
            {
                Amount = 55m,
                PaymentScheme = PaymentScheme.Bacs
            };

            var account = accountBuilder.GetAccount("TEST", 155m, AccountStatus.Live, AllowedPaymentSchemes.FasterPayments);

            var accountDataStoreMock = new Mock<IAccountDataStore>();
            accountDataStoreMock.Setup(x => x.GetAccount(It.IsAny<string>())).Returns(account);
            accountDataStoreMock.Setup(x => x.UpdateAccount(It.IsAny<Account>()));

            var accountDataStoreFactoryMock = new Mock<IAccountDataStoreFactory>();
            accountDataStoreFactoryMock.Setup(x => x.Create()).Returns(accountDataStoreMock.Object);

            var paymentValidatorMock = new Mock<IPaymentValidator>();
            paymentValidatorMock.Setup(x => x.IsPaymentValid(It.IsAny<Account>(), It.IsAny<decimal>())).Returns(false);


            var service = new PaymentService(accountDataStoreFactoryMock.Object, new PaymentRuleSelector());

            // Act
            var result = service.MakePayment(request);

            //Assert
            Assert.False(result.Success);
            Assert.Equal(155, account.Balance);
            accountDataStoreMock.Verify(x => x.UpdateAccount(It.IsAny<Account>()), Times.Never);

        }
    }

}