﻿using ClearBank.DeveloperTest.Data;
using ClearBank.DeveloperTest.Factories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ClearBank.DeveloperTest.Tests.FactoryTests
{
    public class AccountDataStoreFactoryTests
    {
        [Theory]
        [InlineData("Backup", typeof(BackupAccountDataStore))]
        [InlineData("backup", typeof(CurrentAccountDataStore))]
        [InlineData("Primary", typeof(CurrentAccountDataStore))]
        [InlineData("", typeof(CurrentAccountDataStore))]
        [InlineData(null, typeof(CurrentAccountDataStore))]
        public void Create_ShouldReturnCorrectDataStoreType_BasedOnDataStoreType(string dataStoreType, Type expectedDataStoreType)
        {
            // Arrange
            var factory = new AccountDataStoryFactory(dataStoreType);

            // Act
            var result = factory.Create();

            // Assert
            Assert.IsType(expectedDataStoreType, result);
        }
    }
}
