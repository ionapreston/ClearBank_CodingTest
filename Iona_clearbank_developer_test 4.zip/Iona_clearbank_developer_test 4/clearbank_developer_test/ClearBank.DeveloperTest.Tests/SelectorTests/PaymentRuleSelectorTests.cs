﻿using ClearBank.DeveloperTest.Selectors;
using ClearBank.DeveloperTest.Types;
using ClearBank.DeveloperTest.Validators;
using Xunit;

namespace ClearBank.DeveloperTest.Tests.SelectorTests
{
    public class PaymentRuleSelectorTests
    {
        private readonly PaymentRuleSelector paymentRuleSelector = new();

        [Fact]
        public void GetPaymentRule_ShouldReturnBacsValidator_WhenPaymentSchemeBacs() 
        {
            //Act
            var result = paymentRuleSelector.GetPaymentRule(PaymentScheme.Bacs);

            //Assert
            Assert.IsType<BacsValidator>(result);

        }

        [Fact]
        public void GetPaymentRule_ShouldReturnFasterValidator_WhenPaymentSchemeFasterPayment()
        {
            //Act
            var result = paymentRuleSelector.GetPaymentRule(PaymentScheme.FasterPayments);

            //Assert
            Assert.IsType<FasterPaymentValidator>(result);
        }

        [Fact]
        public void GetPaymentRule_ShouldReturnChapsValidator_WhenPaymentSchemeChaps()
        {
            //Act
            var result = paymentRuleSelector.GetPaymentRule(PaymentScheme.Chaps);

            //Assert
            Assert.IsType<ChapsValidator>(result);
        }
    }
}