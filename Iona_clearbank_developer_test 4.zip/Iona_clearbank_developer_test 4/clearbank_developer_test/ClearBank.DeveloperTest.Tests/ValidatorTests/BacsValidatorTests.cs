﻿using ClearBank.DeveloperTest.Tests.Builders;
using ClearBank.DeveloperTest.Types;
using ClearBank.DeveloperTest.Validators;
using Xunit;

namespace ClearBank.DeveloperTest.Tests.ValidatorTests
{
    public class BacsValidatorTests
    {
        private readonly AccountBuilder validatorBuilder = new();
        private readonly BacsValidator bacsValidator = new();
        public BacsValidatorTests()
        {
        }

        [Theory]
        [InlineData("TESTACC", 55.00, AccountStatus.Live, AllowedPaymentSchemes.Bacs, 10, true)]
        [InlineData("TESTACC", 55.00, AccountStatus.Disabled, AllowedPaymentSchemes.Bacs, 60, true)]
        [InlineData("TESTACC", 0, AccountStatus.Live, AllowedPaymentSchemes.Bacs, 0, true)]
        [InlineData("TESTACC", 55.00, AccountStatus.Live, AllowedPaymentSchemes.FasterPayments, 10, false)]
        [InlineData("TESTACC", 55.00, AccountStatus.Live, AllowedPaymentSchemes.Chaps, 10, false)]
        public void IsPaymentValid_ShouldReturnExpectedBool_GivenBacsScheme(string accountNumber, double balance, AccountStatus status, AllowedPaymentSchemes allowedPaymentSchemes, double paymentAmount, bool expectedResult)
        {
            //Arrange
            var account = validatorBuilder.GetAccount(accountNumber, (decimal)balance, status, allowedPaymentSchemes);

            //Act
            var result = bacsValidator.IsPaymentValid(account, (decimal)paymentAmount);

            //Assert
            Assert.True(result == expectedResult);

        }

        [Fact]
        public void IsPaymentValid_ShouldReturnFalse_WhenAccountDoesntExist()
        {
            //Act
            var result = bacsValidator.IsPaymentValid(null, 50.00m);

            //Assert
            Assert.False(result);
        }
    }
}
