﻿using ClearBank.DeveloperTest.Tests.Builders;
using ClearBank.DeveloperTest.Types;
using ClearBank.DeveloperTest.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace ClearBank.DeveloperTest.Tests.ValidatorTests
{
    public class FasterPaymentValidatorTests
    {
        private readonly AccountBuilder validatorBuilder = new();
        private readonly FasterPaymentValidator fasterPaymentValidator = new();
        public FasterPaymentValidatorTests()
        {
        }

        [Theory]
        [InlineData("TESTACC", 55.00, AccountStatus.Live, AllowedPaymentSchemes.FasterPayments, 10, true)]
        [InlineData("TESTACC", 55.00, AccountStatus.Live, AllowedPaymentSchemes.FasterPayments, 60, false)]
        [InlineData("TESTACC", 0, AccountStatus.Live, AllowedPaymentSchemes.FasterPayments, 0, false)]
        [InlineData("TESTACC", 55.00, AccountStatus.Live, AllowedPaymentSchemes.Bacs, 10, false)]
        [InlineData("TESTACC", 55.00, AccountStatus.Live, AllowedPaymentSchemes.Chaps, 10, false)]
        public void IsPaymentValid_ShouldReturnExpectedBool_WhenGivenAccountAndPayment(string accountNumber, double balance, AccountStatus status, AllowedPaymentSchemes allowedPaymentSchemes, double paymentAmount, bool expectedResult) 
        {
            //Arrange
            var account = validatorBuilder.GetAccount(accountNumber, (decimal)balance, status, allowedPaymentSchemes);

            //Act
            var result = fasterPaymentValidator.IsPaymentValid(account, (decimal)paymentAmount);

            //Assert
            Assert.True(result == expectedResult);

        }

        [Fact]
        public void IsPaymentValid_ShouldReturnFalse_WhenAccountDoesntExist()
        {
            //Act
            var result = fasterPaymentValidator.IsPaymentValid(null, 50.00m);

            //Assert
            Assert.False(result);
        }

    }
}